class APIEndPoint{

  APIEndPoint._();

  static APIEndPoint apiEndPoint = APIEndPoint._();
  static const String baseUrl  ="https://zenquotes.io/api";

  static const String quotes = "/random/";

}